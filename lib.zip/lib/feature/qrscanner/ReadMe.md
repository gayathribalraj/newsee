## QR Scanner functionality

step 1: create a feature dir qrscanner inside feature dir
in page dir crete QRScannerPage which is a stateful widget
that uses qr_code_scanner
step 2:
