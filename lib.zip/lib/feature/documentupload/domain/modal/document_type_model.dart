class DocumentTypeModel {
  final String code;
  final String desc;

  DocumentTypeModel({required this.code, required this.desc});
}
