import 'package:equatable/equatable.dart';

abstract class DairyDetailsEvent extends Equatable {
  const DairyDetailsEvent();

  @override
  List<Object?> get props => [];
}

class AddDetails extends DairyDetailsEvent {
  final Map<String, dynamic> detail;
  const AddDetails(this.detail);

  @override
  List<Object?> get props => [detail];
}

class DeleteDetails extends DairyDetailsEvent {
  final int index;
  const DeleteDetails(this.index);

  @override
  List<Object?> get props => [index];
}

class DairyDetailsFailed extends DairyDetailsEvent {
  final String error;
  const DairyDetailsFailed(this.error);

  @override
  List<Object?> get props => [error];
}
