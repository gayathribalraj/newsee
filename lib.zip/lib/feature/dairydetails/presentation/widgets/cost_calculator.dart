
import 'package:reactive_forms/reactive_forms.dart';

class CostCalculator {
  static void attachListener({
    required FormGroup liveStockForm,
    required FormGroup dairyForm,
    required FormGroup incomeForm,
  }) {
    liveStockForm.valueChanges.listen((formValues) {
      final values = formValues ?? {};

      final animals = int.tryParse(values['noOfAnimals']?.toString() ?? '0') ?? 0;
      final noOfAnimalsBatch1 = int.tryParse(values['noOfAnimalsBatch1']?.toString() ?? '0') ?? 0;
      final costOfAnimal = int.tryParse(values['costOfAnimal']?.toString() ?? '0') ?? 0;
      final costOfCalf = int.tryParse(values['costOfCalf']?.toString() ?? '0') ?? 0;
      final floorSpaceAdult = int.tryParse(values['floorSpaceAdult']?.toString() ?? '0') ?? 0;
      final floorSpaceCalf = int.tryParse(values['floorSpaceCalf']?.toString() ?? '0') ?? 0;
      final costOfConstruction = int.tryParse(values['costOfConstruction']?.toString() ?? '0') ?? 0;
      final averageMilkYield = int.tryParse(values['averageMilkYield']?.toString() ?? '0') ?? 0;
      final insurancePremium = int.tryParse(values['insurancePremium']?.toString() ?? '0') ?? 0;
      final veterinary = int.tryParse(values['veterinary']?.toString() ?? '0') ?? 0;
      final feed = int.tryParse(values['costConcentrateFeed']?.toString() ?? '0') ?? 0;
      final sellingPrice = int.tryParse(values['sellingPrice']?.toString() ?? '0') ?? 0;
      final salePrice = int.tryParse(values['salePrice']?.toString() ?? '0') ?? 0;
      final lactationDays = int.tryParse(values['lactationDays']?.toString() ?? '0') ?? 0;
      final value = int.tryParse(values['value']?.toString() ?? '0') ?? 0;

      final power = int.tryParse(values['power']?.toString() ?? '0') ?? 0;
      final salary = int.tryParse(values['salary']?.toString() ?? '0') ?? 0;
      final admin = int.tryParse(values['admin']?.toString() ?? '0') ?? 0;
      final miscExpenses = int.tryParse(values['miscExpenses']?.toString() ?? '0') ?? 0;

      final costOfMilch = animals * costOfAnimal;
      final costShedAdult = animals * floorSpaceAdult * costOfConstruction;
      final costShedCalf = noOfAnimalsBatch1 * floorSpaceCalf * costOfConstruction;
      final capitalCost = costOfMilch + costShedAdult + costShedCalf;
      final costOfFirstBatch = noOfAnimalsBatch1 * feed * 30;
      final costOfInsurance = 2 * costOfAnimal * 0.05 * insurancePremium;
      final reccuringCost = costOfFirstBatch + costOfInsurance;
      final totalCost = capitalCost + reccuringCost;
      final margin = totalCost * 0.15;
      final loanAmountB = totalCost - margin;

      dairyForm.patchValue({
        'costOfMilch': costOfMilch.toString(),
        'costShedAdult': costShedAdult.toString(),
        'costShedCalf': costShedCalf.toString(),
        'capitalCost': capitalCost.toString(),
        'costOfFirstBatch': costOfFirstBatch.toString(),
        'costOfInsurance': costOfInsurance.toString(),
        'reccuringCost': reccuringCost.toString(),
        'totalCost': totalCost.toString(),
        'margin': margin.toString(),
        'loanAmountB': loanAmountB.toString(),
      }, emitEvent: false);

      final lactation = lactationDays;
      final milkYield = animals * averageMilkYield;
      final milkIncome = milkYield * sellingPrice;
      final gunnnyIncome = animals * salePrice;
      final calvesIncome = noOfAnimalsBatch1 * costOfCalf;
      final mannureIncome = animals * value;

      final totalIncome = lactation +
          milkYield +
          milkIncome +
          gunnnyIncome +
          calvesIncome +
          mannureIncome;

      final feedingCost = animals * feed;
      final medicineCost = animals * veterinary;
      final insurance = animals * insurancePremium;
      final totalExpenses = feedingCost +
          medicineCost +
          power +
          salary +
          admin +
          miscExpenses +
          insurance;

      final incomeOverExpenditure = totalIncome - totalExpenses;


      incomeForm.patchValue({
        'lactation': lactation.toString(),
        'milkYield': milkYield.toString(),
        'milkIncome': milkIncome.toString(),
        'gunnnyIncome': gunnnyIncome.toString(),
        'calvesIncome': calvesIncome.toString(),
        'mannureIncome': mannureIncome.toString(),
        'totalIncome': totalIncome.toString(),
        'feedingCost': feedingCost.toString(),
        'medicineCost': medicineCost.toString(),
        'power': power.toString(),
        'salary': salary.toString(),
        'admin': admin.toString(),
        'miscExpenses': miscExpenses.toString(),
        'insurance': insurance.toString(),
        'totalExpenses': totalExpenses.toString(),
        'incomeOverExpenditure': incomeOverExpenditure.toString(),
      }, emitEvent: false);
    });
  }
}
