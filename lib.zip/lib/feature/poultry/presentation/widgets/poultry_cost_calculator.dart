import 'package:reactive_forms/reactive_forms.dart';

class PoultryCostCalculator {
  static void attachListener({
    required FormGroup investment,
    required FormGroup purchase,
    required FormGroup maintenance,
  }) {
    
    // Investment form calculation
    investment.valueChanges.listen((values) {
      print("print investment values  $values");
      final formValues = values ?? {};
      final noOfUnitsX =
          int.tryParse(formValues['noOfUnitsX']?.toString() ?? '0') ?? 0;
      final porposedCostY =
          int.tryParse(formValues['porposedCostY']?.toString() ?? '0') ?? 0;

      final costXY = noOfUnitsX * porposedCostY;

      investment.control('costXY')
          .updateValue(costXY.toString(), emitEvent: false);
    });

    // Purchase form calculation
    purchase.valueChanges.listen((values) {
      final formValues = values ?? {};
      final noOfUnitsA =
          int.tryParse(formValues['noOfUnitsA']?.toString() ?? '0') ?? 0;
      final porposedCostB =
          int.tryParse(formValues['porposedCostB']?.toString() ?? '0') ?? 0;

      final costAB = noOfUnitsA * porposedCostB;

      purchase.control('costAB')
          .updateValue(costAB.toString(), emitEvent: false);
    });

    // Maintenance form calculation
    maintenance.valueChanges.listen((values) {
      final formValues = values ?? {};
      final noOfUnitsD =
          int.tryParse(formValues['noOfUnitsD']?.toString() ?? '0') ?? 0;
      final porposedCostE =
          int.tryParse(formValues['porposedCostE']?.toString() ?? '0') ?? 0;

      final costDE = noOfUnitsD * porposedCostE;

      maintenance.control('costDE')
          .updateValue(costDE.toString(), emitEvent: false);
    });
  }
}
