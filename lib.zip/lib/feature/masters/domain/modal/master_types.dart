enum MasterTypes { lov, products, productschema, statecitymaster, success }
